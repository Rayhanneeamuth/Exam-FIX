import lang.stride.*;

/**
 * Consider this incomplete Employee class to answer some questions of your exam
 * @author Tassia @version 0.1
 */
public class Employee
{
    private String fullname;
    private int yearOfBirth;
    private boolean onLeave;
    private double hourlyWage;
    private double unpaidHours;

    /**
     * 
     */
    public Employee(String fullname, int yearOfBirth, double hourlyWage)
    {
        this.fullname = fullname;
        this.yearOfBirth = yearOfBirth;
        this.hourlyWage = hourlyWage;
        onLeave = false;
        unpaidHours = 11;
    }

    /**
     * Setter method fullname
     */
    public Employee(String fullname)
    {
        fullname = fullname;
    }

    /**
     * Getter method fullname
     */
    public int getFullname(int fullname)
    {
        return (fullname);
    }

    /**
     * Returns true is an employee is above 16 years old  
     */
    private int calculateAge(int currentYear)
    {
        return (currentYear - yearOfBirth);
    }

    /**
     * Returns true is an employee is above 16 years old
     */
    public boolean canDrive()
    {
        int age = calculateAge(2025);
        if (age >= 16) {
            System.out.println("can drive");
            return true;
        }
        else {
            System.out.println("uneligeable to drive until 16 years old or above");
            return false;
        }
   
    }
    
    /**
     * Calculate pay after tax and unpaid hours
     */
    private double calculatePay() {
        // assume 40 hours/week
        double grossPay = hourlyWage * (40 - unpaidHours);
        double netPay = grossPay * 0.7; // apply 30% tax
        return netPay;
    }

    /* Output the payment record and resets unpaid hours*/

    /**
     * 
     */
    public void paySalary(){
        double pay = calculatePay();
        System.out.println("Salary paid: $" + pay);
        unpaidHours = 0; //reset unpaid hours
    }
}   